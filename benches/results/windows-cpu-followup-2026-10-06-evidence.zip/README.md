# Windows 후속 검증 근거

validation-summary.json이 최종 결과를 요약합니다. semantics-topk-final은 24회 최종 결과이고 semantics-current는 보강 전 16회 결과입니다. *red* 로그와 initial-release-timeout은 실패 기록으로 보존하며 통과로 세지 않습니다. manifest.json에 원본 파일 및 최종 소스 해시를 기록했습니다.
