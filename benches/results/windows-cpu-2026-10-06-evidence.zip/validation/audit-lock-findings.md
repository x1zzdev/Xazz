# Windows 감사로그 잠금 경합 비교 진단

2026-10-06. 워크스페이스 병렬 테스트에서 실패한 다음 두 검사는 아직 해결되지 않았다.

- `tests::inference_check_blocks_leaked_secret`
- `tests::inference_check_passes_clean_response`

최초 실패 기록은 `rust-workspace-tests-no-debug-info.log`에 보존한다. 본 진단은 서버 생산 코드나 기존 감사로그를 수정하지 않았다. 실패 테스트를 성공으로 간주하지 않는다.

## 기존 기록에 대한 읽기 전용 확인

`xazz-server/audit_log/audit.jsonl`의 24개 레코드, 9,665바이트를 읽어 SHA-256 재계산, `prev_hash` 연결, 순번을 독립 검증했다. 검사 시점의 모든 레코드는 유효했다. 기존 파일의 생성 시각은 2026-10-02이고 마지막 수정 시각은 2026-10-06 10:01:28이었다. 삭제·정리·재작성하지 않았다.

## 코드에서 확인한 동작

- `xazz-server/src/audit_log.rs:18-19`: 기본 경로가 작업 디렉터리의 `audit_log/audit.jsonl`로 고정되어 있다. 테스트 전용 환경변수 경로 선택은 없다.
- 같은 파일의 `append_to_path`: 프로세스 내부 `APPEND_LOCK`을 잡고 파일을 read+append로 열어 `fs2::FileExt::lock_exclusive`로 배타적 파일 잠금을 잡는다. 잠긴 동일 핸들로 읽고 쓰며 마지막에 잠금을 해제한다.
- 같은 파일의 `read_all:254`: `std::fs::read_to_string(file_path)`를 잠금 없이 호출한다. 별도 핸들로 읽기 때문에 Windows에서 다른 쓰기 핸들의 배타적 잠금과 충돌할 수 있다.
- 같은 파일의 `verify_chain:284`: `let records = all()?;`이므로 읽기 실패는 `Err`로 반환된다. 읽기 성공 후 해시 검증 불일치라면 `Ok(false)`를 반환한다.
- `xazz-server/src/main.rs:2216`: 추론 검사 핸들러는 `audit_log::verify_chain().unwrap_or(false)`를 사용한다. 따라서 읽기 오류인 `Err`와 실제 체인 불일치인 `Ok(false)`가 모두 응답의 `chain_valid=false`로 나타난다. 최초 두 테스트의 출력에는 이 둘을 구별할 원래 오류가 남아 있지 않다.
- 로컬 `fs2-0.4.3/src/windows.rs`의 `lock_exclusive`는 `LockFileEx`에 `LOCKFILE_EXCLUSIVE_LOCK` 및 전체 파일 범위 `0xFFFFFFFF, 0xFFFFFFFF`를 전달한다. 독립 재현도 같은 API·플래그·범위를 사용했다.

## 별도 파일을 이용한 실제 재현

실행 명령:

```powershell
python target/qa-166/audit-lock-repro.py
```

코드는 새 파일을 `xb`로 만들므로 기존 파일을 덮어쓰지 않는다. 생성한 파일은 `audit-lock-fixture-30856.jsonl`이며 기존 감사로그와 무관하다. 외부 라이브러리는 설치하지 않았다.

| 조건 | 별도 프로세스의 Python 읽기 | 별도 핸들의 Win32 ReadFile | 읽기 프로세스 종료 코드 |
| --- | --- | --- | ---: |
| 잠금 전 | 성공, 39바이트 | 성공, 39바이트 | 0 |
| 배타적 잠금 유지 중 | PermissionError, errno 13 | 실패, Windows 오류 33 | 1 |
| 명시적 잠금 해제 후 | 성공, 39바이트 | 성공, 39바이트 | 0 |

배타적 잠금 중 `CreateFileW`는 성공하고 `ReadFile`에서 오류 33이 발생했다. 파일은 재현 전후 바이트가 같았고 SHA-256은 `ac5ef841d5c367cccfed845622479f1404d8526e25f3459d9afff8a2bc30ce9b`다. 원시 결과는 `audit-lock-result.json`, 전체 코드는 `audit-lock-repro.py`에 보존했다.

잠금 전·중·후는 조건이 다른 명시적 비교 실험이다. 중간 실패를 숨겨 성공할 때까지 재시도한 것이 아니며 실패 종료 코드와 원래 Windows 오류를 그대로 저장했다.

## 결론과 한계

현재 코드의 읽기 방식은 Windows 배타적 쓰기 잠금과 실제로 충돌한다. 파일 내용이 온전해도 읽기 오류가 나고, 현재 추론 핸들러는 이 오류를 `chain_valid=false`로 바꾸므로 테스트에 나타난 실패 형태를 설명할 수 있다. 다만 최초 두 실패에서는 원래 오류가 소거되어 직접 수집되지 않았으므로 해당 두 실행의 실제 오류 코드가 33이었다고 확정하지 않는다.

기존 체인 손상은 읽기 전용 독립 검증에서 발견되지 않았다. 전체 테스트의 직렬 실행은 병렬 경쟁 여부를 비교하기 위한 추가 진단이며, 병렬 테스트 실패를 해결하거나 기존 실패 기록을 대체하지 않는다. 서버 수정은 이번 벤치마크·런타임 변경 범위에서 제외했다.
