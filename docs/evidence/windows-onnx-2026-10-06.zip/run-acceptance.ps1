param(
    [ValidateSet('onnx','onnx-cuda')][string]$Feature,
    [ValidateSet('cpu','cuda')][string]$Ep,
    [ValidatePattern('^[a-z0-9-]+$')][string]$Prefix,
    [string]$Device = '',
    [switch]$LibOnly
)
$ErrorActionPreference = 'Stop'
& 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:CARGO_TARGET_DIR = '<QA_ROOT>/target/onnx-msvc'
$env:XAZZ_LANG = 'en'
$env:XAZZ_ORT_EP = $Ep
if ($Device) { $env:XAZZ_DEVICE = $Device } else { Remove-Item Env:XAZZ_DEVICE -ErrorAction SilentlyContinue }
if ($Feature -eq 'onnx-cuda') { $env:ORT_CUDA_VERSION = '13' } else { Remove-Item Env:ORT_CUDA_VERSION -ErrorAction SilentlyContinue }
$qaLog = Join-Path $PSScriptRoot ($Prefix + '.log')
$qaResult = Join-Path $PSScriptRoot ($Prefix + '.result.json')
if ((Test-Path -LiteralPath $qaLog) -or (Test-Path -LiteralPath $qaResult)) { throw '기존 실행 근거를 덮어쓸 수 없습니다' }
$qaWatch = [System.Diagnostics.Stopwatch]::StartNew()
$qaCargoArgs = @('+stable-x86_64-pc-windows-msvc','test','--release','--locked','-p','xazz-exec','--features',$Feature,'-j','8')
if ($LibOnly) { $qaCargoArgs += '--lib' }
$qaCargoArgs += @('--','--ignored','--nocapture')
cargo @qaCargoArgs *> $qaLog
$qaExit = $LASTEXITCODE
@{
    exit_code = $qaExit
    elapsed_seconds = $qaWatch.Elapsed.TotalSeconds
    command = 'cargo ' + ($qaCargoArgs -join ' ')
    XAZZ_ORT_EP = $Ep
    XAZZ_DEVICE = $Device
    ORT_CUDA_VERSION = $env:ORT_CUDA_VERSION
    source_head = (git rev-parse HEAD)
} | ConvertTo-Json | Set-Content -LiteralPath $qaResult
Write-Output ($Prefix + ' exit: ' + $qaExit)
exit $qaExit
