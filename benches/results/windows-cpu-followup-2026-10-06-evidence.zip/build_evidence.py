"""후속 검증 근거를 원본 바이트와 해시를 유지해 보관한다."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = Path(__file__).resolve().parent
RESULTS = ROOT / "benches/results"


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


semantic = load(QA / "semantics-topk-final.json")
assert semantic["status"] == "ok" and semantic["expected_runs"] == len(semantic["runs"]) == 24
assert all(run["status"] == "ok" and run["exit_code"] == 0 for run in semantic["runs"])
assert semantic["binary_sha256"] == digest(Path(semantic["xazz_exec"]))
for name, expected in semantic["source_sha256"].items():
    assert digest(ROOT / "benches" / name) == expected
cli = load(QA / "cli-output-current.json")
assert cli["status"] == "ok" and len(cli["cases"]) == 6
assert all(case["status"] == "ok" for case in cli["cases"])
for name, expected in cli["binary_sha256"].items():
    assert digest(ROOT / f"target/debug/{name}.exe") == expected
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                    (QA / "workspace-parallel.log").read_text(encoding="utf-8"))
totals = [sum(int(count[i]) for count in counts) for i in range(3)]
assert totals == [677, 0, 0], totals
python_log = (QA / "python-topk-final.log").read_text(encoding="utf-8")
assert "Ran 69 tests" in python_log and "OK (skipped=1)" in python_log
historical_names = ["windows-cpu-2026-10-06.json", "windows-cpu-2026-10-06.verification.json",
                    "windows-cpu-200m-2026-10-06.json", "windows-cpu-200m-2026-10-06.verification.json",
                    "windows-cpu-2026-10-06-evidence.zip"]
summary = {
    "date": "2026-10-06", "base_commit": "a3ec9a91d2f7874b8adf9fd7112abacaa04df35a",
    "status": "ok", "build": {"profile": "dev", "CARGO_PROFILE_DEV_DEBUG": "0", "target": "x86_64-pc-windows-gnu"},
    "rust_parallel": {"passed": totals[0], "failed": totals[1], "ignored": totals[2], "server_passed": 118},
    "python": {"total": 69, "passed": 68, "failed": 0, "skipped": 1, "skip_reason": "기존 POSIX 프로세스 그룹 검사: Windows 비적용"},
    "semantic_runs": {"expected": 24, "passed": 24, "report": "semantics-topk-final.json"},
    "cli_output_cases": {"expected": 6, "passed": 6, "report": "cli-output-current.json"},
    "fmt": "통과", "clippy": "통과", "diff_check": "통과",
    "ci": "YAML 파싱·단계 연결 로컬 확인, 원격 실행 전",
    "binary_sha256": cli["binary_sha256"],
    "historical_performance_evidence_sha256": {name: digest(RESULTS / name) for name in historical_names},
    "limitations": ["이번 후속 수정으로 200M 성능을 다시 측정하지 않았다.",
                    "작은 입력은 기존 대용량 실행에서 출력하지 않은 셀의 사후 검증이 아니다.",
                    "최초 실패·컴파일 오류·release timeout과 중간 16회 성공 기록을 별도로 보존한다.",
                    "GPU 및 #127·#129 작업은 진행하지 않았다."]}
save(QA / "validation-summary.json", summary)
report_target = RESULTS / "windows-cpu-followup-2026-10-06.verification.json"
report_target.write_bytes((QA / "semantics-topk-final.json").read_bytes())
files = {path.relative_to(QA).as_posix(): path for path in QA.rglob("*") if path.is_file()}
for path in (ROOT / "target/qa-166").glob("semantic-release-first*"):
    if path.is_file():
        files["initial-release-timeout/" + path.name] = path
    elif path.is_dir():
        for child in path.rglob("*"):
            if child.is_file():
                files["initial-release-timeout/" + path.name + "/" + child.relative_to(path).as_posix()] = child
for name in ("python-semantics-unit-final.log", "python-semantics-topk-unit.log"):
    path = ROOT / "target/qa-166" / name
    if path.is_file():
        files["intermediate/" + name] = path
source_paths = ["xazz-exec/src/runtime.rs", "xazz-exec/tests/runtime_errors.rs", "xazz-exec/tests/dp_budget.rs",
                "xazz-server/src/audit_log.rs", "xazz-server/src/main.rs", ".github/workflows/ci.yml",
                "benches/requirements.txt", "benches/benchmark_semantics.py", "benches/verify_benchmark_semantics.py",
                "benches/test_verify_benchmark_semantics.py", "benches/test_pandas_pipeline.py",
                "benches/run_readme_benchmark.py", "benches/test_run_readme_benchmark.py",
                "benches/verify_benchmark_results.py", "benches/test_verify_benchmark_results.py"]
manifest = {"description": "후속 검증 원본 바이트와 최종 코드 해시. 과거 측정 소스와 구분한다.",
            "files": {name: {"bytes": path.stat().st_size, "sha256": digest(path)} for name, path in sorted(files.items())},
            "source_sha256": {name: digest(ROOT / name) for name in source_paths}}
archive = RESULTS / "windows-cpu-followup-2026-10-06-evidence.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
    for name, path in sorted(files.items()):
        output.write(path, name)
    output.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    output.writestr("README.md", "# Windows 후속 검증 근거\n\nvalidation-summary.json이 최종 결과를 요약합니다. semantics-topk-final은 24회 최종 결과이고 semantics-current는 보강 전 16회 결과입니다. *red* 로그와 initial-release-timeout은 실패 기록으로 보존하며 통과로 세지 않습니다. manifest.json에 원본 파일 및 최종 소스 해시를 기록했습니다.\n")
with zipfile.ZipFile(archive) as stored:
    assert stored.testzip() is None
    for name, path in files.items():
        assert stored.read(name) == path.read_bytes(), name
assert report_target.read_bytes() == (QA / "semantics-topk-final.json").read_bytes()
print(json.dumps({"status": "ok", "archived_original_files": len(files), "archive_bytes": archive.stat().st_size,
                  "archive_sha256": digest(archive), "source_files": len(source_paths)}, ensure_ascii=False))
