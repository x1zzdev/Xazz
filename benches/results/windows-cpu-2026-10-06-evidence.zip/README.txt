small-large/와 200m/는 release 실측 원시 stdout·stderr·프로세스 측정 기록입니다.
validation/은 초기 실패·중간 검사·최종 검증을 함께 보존합니다.
Rust 병렬 서버 검사 2개 실패와 직렬 비교 통과를 서로 대체하지 않습니다.
원본 결과 JSON은 수정하지 않았습니다. 다른 경로에서 검증할 때는
benches/verify_benchmark_results.py --results 결과.json --logs-dir 압축해제경로/200m 형태로 지정합니다.
검증 범위와 한계는 docs/benchmark-scale-166-windows-2026-10-06.md를 참조하세요.
