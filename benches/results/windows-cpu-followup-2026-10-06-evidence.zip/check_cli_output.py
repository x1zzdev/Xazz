"""현재 debug CLI에서 CSV 출력 성공·실패의 전파를 확인한다."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
FIXTURE = OUT / "cli-output-cases"
FIXTURE.mkdir(exist_ok=True)
(FIXTURE / "occupied").mkdir(exist_ok=True)
(FIXTURE / "data.csv").write_text("a,b\n1,10\n2,20\n", encoding="utf-8")
(FIXTURE / "pipeline.xzz").write_text('type S = { a: int, b: int };\nv result = load("data.csv") :: S |> filter(a > 1);\n', encoding="utf-8")
binary = ROOT / "target/debug/xazz.exe"
env = dict(os.environ, XAZZ_LANG="en", XAZZ_BACKEND="cpu", XAZZ_STREAMING="1",
           XAZZ_COLLECT_DIAGNOSTICS="1", XAZZ_EXEC_PATH=str(ROOT / "target/debug/xazz-exec.exe"))
for key in ("POLARS_AUTO_NEW_STREAMING", "POLARS_FORCE_NEW_STREAMING"):
    if env.get(key) == "1":
        raise RuntimeError(f"{key}=1")
report = {"status": "failed", "binary_sha256": {}, "cases": []}
for name in ("xazz", "xazz-runner", "xazz-exec"):
    with (ROOT / f"target/debug/{name}.exe").open("rb") as source:
        report["binary_sha256"][name] = hashlib.file_digest(source, "sha256").hexdigest()
try:
    for structured in (False, True):
        for case, path, expected in (("valid", f"valid-{structured}.csv", 0),
                                     ("missing-parent", "missing-parent/result.csv", 1),
                                     ("directory", "occupied", 1)):
            name = f"{case}-{'json' if structured else 'plain'}"
            cmd = [str(binary), "run", "pipeline.xzz", "--output", path]
            if structured:
                cmd.append("--json")
            result = subprocess.run(cmd, cwd=FIXTURE, env=env, capture_output=True, timeout=30)
            stdout, stderr = result.stdout.decode("utf-8"), result.stderr.decode("utf-8")
            (FIXTURE / f"{name}.stdout.log").write_bytes(result.stdout)
            (FIXTURE / f"{name}.stderr.log").write_bytes(result.stderr)
            record = {"case": name, "command": cmd, "exit_code": result.returncode, "status": "failed"}
            report["cases"].append(record)
            assert result.returncode == expected, (name, stdout, stderr)
            if structured:
                payload = json.loads(stdout)
                assert payload["success"] is (expected == 0) and payload["exit_code"] == expected
                if expected:
                    assert payload["rows"] == [] and payload["schema"] == []
                    assert "failed to create CSV file" in payload["error"] and "os error" in payload["error"]
                else:
                    assert payload["rows"] == [{"a": 2, "b": 20}]
            elif expected:
                assert "failed to create CSV file" in stderr and "os error" in stderr
                for marker in ("[xazz:timing]", "[xazz:result]", "Execution Result", "CSV saved"):
                    assert marker not in stdout, (name, marker)
            else:
                assert stdout.count("[xazz:timing]") == 1 and stdout.count("[xazz:result]") == 1
            if expected == 0:
                with (FIXTURE / path).open(newline="", encoding="utf-8") as source:
                    assert list(csv.reader(source)) == [["a", "b"], ["2", "20"]]
            else:
                assert not (FIXTURE / path).is_file()
            record["status"] = "ok"
    report["status"] = "ok"
except Exception as error:
    report["error"] = repr(error)
finally:
    (OUT / "cli-output-current.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False))
raise SystemExit(0 if report["status"] == "ok" else 1)
